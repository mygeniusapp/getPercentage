# getPercentage
A JavaFX application that calculates the net percentage of a given number plus the initial number.

## Features
- Enter an initial number.
- Enter a percentage.
- Calculate and display the net percentage and final result.

## Requirements
- Java Development Kit (JDK)
- JavaFX SDK

## How to Run
1. Clone the repository or download the ZIP.
2. Compile the Java files.
3. Run `main.java` to start the application.
